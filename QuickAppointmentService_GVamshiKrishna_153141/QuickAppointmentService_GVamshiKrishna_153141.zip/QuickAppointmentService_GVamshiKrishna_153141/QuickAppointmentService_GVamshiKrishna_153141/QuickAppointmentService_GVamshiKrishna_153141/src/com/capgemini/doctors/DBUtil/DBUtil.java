package com.capgemini.doctors.DBUtil;

import java.util.HashMap;
import java.util.Map;
import com.capgemini.doctors.bean.DoctorAppointment; 

public class DBUtil
{
	Map<Integer, DoctorAppointment> appointments = new HashMap<Integer, DoctorAppointment>();
	
	
}
